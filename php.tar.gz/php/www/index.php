<?php
mysqli_connect("db", "root", "phprs") or die(mysqli_error());
echo "Deu bom :DL<br />";